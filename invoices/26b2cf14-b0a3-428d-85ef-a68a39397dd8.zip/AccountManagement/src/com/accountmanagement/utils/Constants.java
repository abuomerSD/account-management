
package com.accountmanagement.utils;

public class Constants {
    
    public static String REPORTS_PATH = "/reports/";
    public static String ADMIN_USER_NAME = "admin";
    public static String ADMIN_PASSWORD = "12345";
    
}
